from django import template
import os

register = template.Library()

@register.filter
def is_video(file_name):
    _, extension = os.path.splitext(file_name)
    return extension.lower() in ['.mp4', '.webm', '.ogg']

@register.filter
def is_image(file_name):
    _, extension = os.path.splitext(file_name)
    return extension.lower() in ['.jpg', '.jpeg', '.png', '.gif']
